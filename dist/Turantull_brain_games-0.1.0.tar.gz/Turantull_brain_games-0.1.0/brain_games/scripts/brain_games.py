# -*- coding:utf-8 -*-

"""Script."""

from brain_games import cli


def main():
    """Run script."""
    cli.welcome()
    cli.welcome_user()


if __name__ == '__main__':
    main()
