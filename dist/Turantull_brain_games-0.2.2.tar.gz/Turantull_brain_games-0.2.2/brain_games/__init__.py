"""brain games init."""
