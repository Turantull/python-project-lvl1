from .brain_games import main

__all__ = (
        'main',
    )
